player_health = 100
player_mp = 10
player_xp = 0
player_lvl = 1
player_defence = 10
player_damage = 10
last_save = str('Sunday, 17 March, 2024 10:01:11')
